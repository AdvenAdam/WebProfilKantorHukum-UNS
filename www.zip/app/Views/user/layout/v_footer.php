  <!--====== footer PART START ======-->
  <footer class="footer-area footer-area-2 footer-area-1 bg_cover">
      <div class="footer-overlay">
          <div class="container position-relative">
              <div class="row">
                  <div class="col">
                      <center>
                          <h2 class="title" style="color: white;">
                              Bagian Kantor Hukum UNS
                          </h2>
                          <h4 class="title" style="color: white;">
                              Universitas Sebelas Maret
                          </h4>
                      </center>
                  </div>
              </div> <!-- row -->
              <div class="row">
                  <div class="col-lg-12">
                      <div class="footer-copyright">
                          @UNS2021
                      </div> <!-- footer copyright -->
                  </div>
              </div> <!-- row -->
          </div> <!-- container -->
      </div>
  </footer>

  <!--====== footer PART ENDS ======-->
  <!--====== BACK TO TOP ======-->
  <div class="back-to-top back-to-top-2">
      <a href="">
          <i class="fas fa-arrow-up"></i>
      </a>
  </div>
  <!--====== BACK TO TOP ======-->
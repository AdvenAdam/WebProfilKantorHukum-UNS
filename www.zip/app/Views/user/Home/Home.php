<?= $this->extend('user/layout/v_main'); ?>
<?= $this->section('content'); ?>

<?= $this->include('user/Home/Slider'); ?>
<?= $this->include('user/Home/Tentang'); ?>
<?= $this->include('user/Home/ProdukHukum'); ?>
<?= $this->include('user/Home/Kontak'); ?>


<?= $this->endSection(); ?>